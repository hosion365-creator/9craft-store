const ranksData = [
    {
        id: 1,
        name: "رنک Iron",
        price: 29000,
        features: [
            "کیت روزانه Iron",
            "۳ خانه (/sethome)",
            "دسترسی به /kit iron",
            "دسترسی به /spawn و /home",
            "تلپورت سریع‌تر (۳ ثانیه انتظار)",
            "پیشوند اختصاصی [Iron] در چت",
            "امکان استفاده از کدهای رنگی ساده در چت"
        ],
        class: ""
    },
    {
        id: 2,
        name: "رنک Gold",
        price: 49000,
        features: [
            "کیت روزانه Gold",
            "۵ خانه (/sethome)",
            "پیشوند طلایی [Gold] در چت",
            "دسترسی به دستور /hat",
            "دسترسی به /workbench همراه",
            "ورود سریع‌تر به سرور (بایپس صف معمولی)",
            "جایزه روزانه ۲ برابر",
            "قابلیت رنگی نوشتن دائمی در چت"
        ],
        class: ""
    },
    {
        id: 3,
        name: "رنک VIP",
        price: 79000,
        features: [
            "کیت هفتگی VIP",
            "۸ خانه (/sethome)",
            "پرواز در لابی اصلی سرور",
            "پیشوند سبز [VIP] در چت",
            "دسترسی به دستور حیاتی /feed",
            "دسترسی به /craft اختصاصی",
            "صف ورود کاملاً اختصاصی",
            "جایزه ۲۰٪ بیشتر در تمامی ایونت‌ها",
            "دریافت کوین بیشتر از فعالیت در سرور"
        ],
        class: "featured"
    },
    {
        id: 4,
        name: "رنک Diamond",
        price: 119000,
        features: [
            "کیت قدرتمند Diamond",
            "۱۲ خانه (/sethome)",
            "امکان ساخت فروشگاه پلیر شخصی",
            "دسترسی به دستور کاربردی /heal",
            "دسترسی به /enderchest از هر جا",
            "پیشوند الماسی [Diamond] در چت",
            "تخفیف ۱۰ درصدی در وارپ شاپ سرور",
            "دریافت پاداش کوین اضافه از ماین کردن",
            "سرعت دویدن بیشتر در لابی"
        ],
        class: ""
    },
    {
        id: 5,
        name: "رنک MVP",
        price: 159000,
        features: [
            "کیت ویژه MVP",
            "۱۵ خانه (/sethome)",
            "ذرات جادویی دور بازیکن (Particles)",
            "پیشوند خاص [MVP] در چت",
            "دسترسی به دستور تغییر نام نمایشی /nick",
            "دسترسی به /ptime (تغییر ساعت شخصی)",
            "امکان تغییر آب‌وهوای شخصی با /pweather",
            "دسترسی به دستور /recipe برای ساخت آسان",
            "ورود به سرور حتی در زمان پر بودن ظرفیت",
            "جایزه روزانه ۳ برابر"
        ],
        class: "featured"
    },
    {
        id: 6,
        name: "رنک MVP+",
        price: 199000,
        features: [
            "کیت فول ندرایت محافظت‌شده",
            "۲۰ خانه (/sethome)",
            "پرواز کامل در تمام بخش‌های مجاز سرور",
            "پیشوند متحرک و رنگارنگ در چت",
            "دسترسی به دستور عمومی /fly",
            "دسترسی به /anvil همراه در هر زمان",
            "دسترسی به /stonecutter پرتابل",
            "تغییر رنگ دلخواه نام در لیست بازیکنان",
            "بدون زمان انتظار برای وارپ‌ها (Instant TP)",
            "شانس ۲ برابر در باز کردن باکس‌های شانس"
        ],
        class: ""
    },
    {
        id: 7,
        name: "رنک ELITE",
        price: 249000,
        features: [
            "کیت ویژه الایت Elite",
            "۲۵ خانه (/sethome)",
            "هاله نوری اختصاصی دور کاراکتر",
            "تغییر نام مستعار با رنگ‌های گرادینت",
            "دسترسی به /grindstone همراه",
            "دسترسی به /loom همراه",
            "دسترسی به /cartographytable همراه",
            "جایزه VIP ویژه در تمامی ایونت‌های سرور",
            "افکت صوتی و تصویری خاص در زمان ورود به سرور",
            "قابلیت شخصی‌سازی پیام ورود برای همه کاربران"
        ],
        class: ""
    },
    {
        id: 8,
        name: "رنک LEGEND",
        price: 299000,
        features: [
            "کیت اسطوره‌ای Legend",
            "۳۰ خانه (/sethome)",
            "کمان اختصاصی با تیرهای انفجاری بی‌خطر",
            "پیشوند طلایی درخشان [LEGEND] در چت",
            "دسترسی به دستور تله‌پورت به بالاترین بلاک /top",
            "تغییر نام آیتم‌ها با دستور /itemname",
            "افکت چت حبابی اختصاصی",
            "امکان ساخت ۲۵ ست‌هوم ویژه برای دوستان",
            "پاداش ۱.۵ برابری برداشت محصولات فارم",
            "تخفیف ۱۵ درصدی در فروشگاه اصلی سرور"
        ],
        class: "god-rank"
    },
    {
        id: 9,
        name: "رنک GOD",
        price: 399000,
        features: [
            "کیت بین‌نظیر GOD",
            "۴۰ خانه (/sethome)",
            "دسترسی به تمام دستورات ادمین غیرمخرب",
            "نام تماماً رنگی و متحرک در لیست چت",
            "نام کاربری خاص و متمایز در بازی",
            "دسترسی به کانال چت مخفی /godchat",
            "دسترسی به دستور /ec برای دسترسی همیشگی به چست",
            "قابلیت شخصی‌سازی افکت‌های ذرات با منو",
            "پاداش فوق‌العاده در ایونت‌ها (۳ برابر)",
            "حق رای دوبرابر در نظرسنجی‌های سرور"
        ],
        class: "god-rank"
    },
    {
        id: 10,
        name: "رنک MASTER",
        price: 499000,
        features: [
            "کیت پیشرفته MASTER",
            "۶۰ خانه (/sethome)",
            "پرواز نامحدود در تمام مپ‌ها بدون محدودیت انرژی",
            "قابلیت زنده کردن دیگر بازیکنان در مپ‌های هاردکور",
            "پیشوند مستر اختصاصی و درخشان",
            "دسترسی به دستور تعمیر آیتم‌ها /repair",
            "دسترسی به /smithingtable همراه در هر جا",
            "شخصی‌سازی کامل قالب چت شخصی",
            "دسترسی به جوایز هفتگی بسیار خاص (Master Chest)",
            "بالاترین اولویت ورود در زمان آپدیت‌ها"
        ],
        class: "god-rank"
    },
    {
        id: 11,
        name: "رنک INFINITY",
        price: 999000,
        features: [
            "کیت افسانه‌ای و بی‌نهایت INFINITY",
            "بی‌نهایت خانه (/sethome)",
            "دسترسی به تمام امکانات پرمیوم و رنک‌های قبلی",
            "دسترسی ویژه به بخش‌های در حال توسعه و تست سرور",
            "تمام دستورات پرمیوم سرور بدون استثنا",
            "پیشوند متحرک بی‌نهایت با رنگ‌های RGB لایو",
            "افکت اختصاصی راه رفتن (موج رنگی زیر پا)",
            "جوایز روزانه، هفتگی و ماهانه بسیار ارزشمند",
            "بالاترین اولویت ورود در مواقع شلوغی سرور",
            "پشتیبانی مستقیم و رسیدگی اولویت‌دار توسط مالکین سرور"
        ],
        class: "god-rank"
    }
];

let cart = JSON.parse(localStorage.getItem("cart") || "[]");
let activeCoupon = null;

function toggleMenu() { 
    document.getElementById("navLinks").classList.toggle("active"); 
}

function showPage(pageId) {
    document.querySelectorAll("section").forEach(s => s.classList.remove("active"));
    document.getElementById(pageId).classList.add("active");
    document.getElementById("navLinks").classList.remove("active");
    
    // Update active nav link
    document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
    const activeLink = document.getElementById(`l-${pageId}`);
    if (activeLink) activeLink.classList.add('active');

    if (pageId === 'cart') loadCart();
}

function renderRanks() {
    const grid = document.getElementById('ranksGrid');
    if (!grid) return;
    grid.innerHTML = '';
    ranksData.forEach(rank => {
        let featuresHtml = rank.features.map(f => `<li>${f}</li>`).join('');
        grid.innerHTML += `
            <div class="card ${rank.class}">
                <h3>${rank.name}</h3>
                <div class="price">${rank.price.toLocaleString()} <span>تومان</span></div>
                <ul>${featuresHtml}</ul>
                <button class="btn btn-primary" onclick="addToCart(${rank.id})">افزودن به سبد خرید</button>
            </div>
        `;
    });
}

function addToCart(rankId) {
    const rank = ranksData.find(r => r.id === rankId);
    const existingItemIndex = cart.findIndex(item => item.id === rankId);
    if (existingItemIndex > -1) {
        cart[existingItemIndex].quantity = (cart[existingItemIndex].quantity || 1) + 1;
    } else {
        cart.push({ ...rank, quantity: 1 });
    }
    updateCartCount();
    localStorage.setItem("cart", JSON.stringify(cart));
    alert(`${rank.name} به سبد خرید اضافه شد!`);
}

function updateCartCount() {
    const totalItems = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
    const badge = document.getElementById('cartBadge');
    if (badge) {
        badge.textContent = totalItems;
        badge.style.display = totalItems > 0 ? 'block' : 'none';
    }
}

function loadCart() {
    const list = document.getElementById('cart-list');
    if (!list) return;
    list.innerHTML = '';
    let subtotal = 0;
    cart.forEach((item, index) => {
        const itemPrice = item.price * (item.quantity || 1);
        subtotal += itemPrice;
        list.innerHTML += `
            <div class="cart-item">
                <div class="cart-item-info"><h4>${item.name}</h4><span>${item.price.toLocaleString()} تومان</span></div>
                <div class="cart-item-actions">
                    <input type="number" value="${item.quantity || 1}" min="1" onchange="updateItemQuantity(${index}, this.value)" style="width: 60px; padding: 5px; border-radius: 8px; background: rgba(0,0,0,0.3); border: 1px solid var(--border); color: white; text-align: center;">
                    <button class="remove-btn" onclick="removeItem(${index})">🗑️</button>
                </div>
            </div>
        `;
    });
    document.getElementById('subtotalPrice').textContent = subtotal.toLocaleString() + ' تومان';
    updateTotalPrice();
    updateCartCount();
}

function updateItemQuantity(index, quantity) {
    quantity = parseInt(quantity);
    if (quantity < 1) quantity = 1;
    cart[index].quantity = quantity;
    localStorage.setItem("cart", JSON.stringify(cart));
    loadCart();
}

function removeItem(index) {
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    loadCart();
}

function applyCoupon() {
    const couponCode = document.getElementById('couponCode').value.trim().toUpperCase();
    const messageElem = document.getElementById('couponMessage');
    if (!messageElem) return;
    
    if (couponCode === "NINE50") {
        activeCoupon = { code: "NINE50", discount: 0.50 };
        messageElem.style.color = 'var(--secondary)';
        messageElem.textContent = "کد تخفیف ۵۰٪ اعمال شد!";
    } else if (couponCode === "WELCOME10") {
        activeCoupon = { code: "WELCOME10", discount: 0.10 };
        messageElem.style.color = 'var(--secondary)';
        messageElem.textContent = "کد تخفیف ۱۰٪ اعمال شد!";
    } else {
        activeCoupon = null;
        messageElem.style.color = 'var(--danger)';
        messageElem.textContent = "کد تخفیف نامعتبر است.";
    }
    updateTotalPrice();
}

function updateTotalPrice() {
    let subtotal = 0;
    cart.forEach(item => subtotal += item.price * (item.quantity || 1));
    document.getElementById('subtotalPrice').textContent = subtotal.toLocaleString() + ' تومان';
    
    let discountValue = 0;
    const discountRow = document.getElementById('discountRow');
    const discountValElem = document.getElementById('discountValue');
    
    if (activeCoupon) {
        discountValue = subtotal * activeCoupon.discount;
        if (discountRow) discountRow.style.display = 'flex';
        if (discountValElem) discountValElem.textContent = discountValue.toLocaleString() + ' تومان';
    } else {
        if (discountRow) discountRow.style.display = 'none';
    }
    
    const total = subtotal - discountValue;
    document.getElementById('totalPrice').textContent = total.toLocaleString() + ' تومان';
}

function proceedToPayment() {
    const ign = document.getElementById('minecraftIGN').value.trim();
    if (!ign) {
        alert("لطفاً نام کاربری (IGN) ماینکرفت خود را وارد کنید.");
        return;
    }
    if (cart.length === 0) {
        alert("سبد خرید شما خالی است.");
        return;
    }
    
    alert(`پرداخت برای IGN "${ign}" با مبلغ ${document.getElementById('totalPrice').textContent} انجام شد. (شبیه‌سازی شده)`);
    
    cart = [];
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCartCount();
    loadCart();
}

function toggleFaq(element) {
    const item = element.closest('.faq-item');
    if (item) item.classList.toggle('open');
}

document.addEventListener('DOMContentLoaded', () => {
    renderRanks();
    updateCartCount();
    if (window.location.hash === '#cart') {
        showPage('cart');
        loadCart();
    } else {
        showPage('home');
    }
});
